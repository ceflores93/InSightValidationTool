﻿namespace WinFormsAppReadIni
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            textBox_Config = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox_Modelo = new TextBox();
            label3 = new Label();
            label_PathImagenes = new Label();
            label_PathJob = new Label();
            label5 = new Label();
            label_IPCamara = new Label();
            label6 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(82, 175);
            button2.Name = "button2";
            button2.Size = new Size(145, 39);
            button2.TabIndex = 0;
            button2.Text = "Read";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox_Config
            // 
            textBox_Config.Location = new Point(135, 12);
            textBox_Config.Name = "textBox_Config";
            textBox_Config.Size = new Size(190, 23);
            textBox_Config.TabIndex = 1;
            textBox_Config.Text = "ConfigSoto.ini";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 15);
            label1.Name = "label1";
            label1.Size = new Size(78, 15);
            label1.TabIndex = 2;
            label1.Text = "Name Config";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 44);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 4;
            label2.Text = "Modelo";
            // 
            // textBox_Modelo
            // 
            textBox_Modelo.Location = new Point(135, 41);
            textBox_Modelo.Name = "textBox_Modelo";
            textBox_Modelo.Size = new Size(190, 23);
            textBox_Modelo.TabIndex = 3;
            textBox_Modelo.Text = "Modelo1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 73);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 6;
            label3.Text = "PathImagenes";
            // 
            // label_PathImagenes
            // 
            label_PathImagenes.AutoSize = true;
            label_PathImagenes.Location = new Point(135, 73);
            label_PathImagenes.Name = "label_PathImagenes";
            label_PathImagenes.Size = new Size(13, 15);
            label_PathImagenes.TabIndex = 7;
            label_PathImagenes.Text = "..";
            // 
            // label_PathJob
            // 
            label_PathJob.AutoSize = true;
            label_PathJob.Location = new Point(135, 105);
            label_PathJob.Name = "label_PathJob";
            label_PathJob.Size = new Size(13, 15);
            label_PathJob.TabIndex = 9;
            label_PathJob.Text = "..";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(31, 105);
            label5.Name = "label5";
            label5.Size = new Size(49, 15);
            label5.TabIndex = 8;
            label5.Text = "PathJob";
            // 
            // label_IPCamara
            // 
            label_IPCamara.AutoSize = true;
            label_IPCamara.Location = new Point(135, 133);
            label_IPCamara.Name = "label_IPCamara";
            label_IPCamara.Size = new Size(13, 15);
            label_IPCamara.TabIndex = 11;
            label_IPCamara.Text = "..";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(31, 133);
            label6.Name = "label6";
            label6.Size = new Size(58, 15);
            label6.TabIndex = 10;
            label6.Text = "IPCamara";
            // 
            // Form1
            // 
            ClientSize = new Size(348, 248);
            Controls.Add(label_IPCamara);
            Controls.Add(label6);
            Controls.Add(label_PathJob);
            Controls.Add(label5);
            Controls.Add(label_PathImagenes);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox_Modelo);
            Controls.Add(label1);
            Controls.Add(textBox_Config);
            Controls.Add(button2);
            Name = "Form1";
            Text = "Read INI";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private TextBox textBox_Config;
        private Label label1;
        private Label label2;
        private TextBox textBox_Modelo;
        private Label label3;
        private Label label_PathImagenes;
        private Label label_PathJob;
        private Label label5;
        private Label label_IPCamara;
        private Label label6;
    }
}
